import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  findActivityLogs,
  createActivityLog,
} from "./queries/activity";

export const activityRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        agentId: z.number().optional(),
        swarmId: z.number().optional(),
        userId: z.number().optional(),
        limit: z.number().min(1).max(100).optional(),
      }).optional()
    )
    .query(async (opts) => findActivityLogs(opts.input ?? {})),

  create: authedQuery
    .input(
      z.object({
        agentId: z.number().optional(),
        swarmId: z.number().optional(),
        action: z.string().min(1),
        details: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => {
      const { ctx, input } = opts;
      return createActivityLog({ ...input, userId: ctx.user.id });
    }),
});
