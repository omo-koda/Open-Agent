import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  findAgentsByUser,
  findPublicAgents,
  findAgentById,
  createAgent,
  updateAgent,
  deleteAgent,
  searchAgents,
} from "./queries/agents";

export const agentRouter = createRouter({
  list: authedQuery.query(async (opts) => findAgentsByUser(opts.ctx.user.id)),

  publicList: authedQuery.query(async () => findPublicAgents()),

  byId: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async (opts) => findAgentById(opts.input.id)),

  create: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        description: z.string().optional(),
        model: z.string().optional(),
        systemPrompt: z.string().optional(),
        thinkingMode: z.boolean().optional(),
        lowLatency: z.boolean().optional(),
        config: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => {
      const { ctx, input } = opts;
      return createAgent({ ...input, ownerId: ctx.user.id });
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        model: z.string().optional(),
        systemPrompt: z.string().optional(),
        status: z.enum(["idle", "active", "busy", "offline", "error"]).optional(),
        isPublic: z.boolean().optional(),
        thinkingMode: z.boolean().optional(),
        lowLatency: z.boolean().optional(),
        config: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => {
      const { input } = opts;
      return updateAgent(input.id, input);
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async (opts) => {
      const { input } = opts;
      return deleteAgent(input.id);
    }),

  search: authedQuery
    .input(z.object({ query: z.string() }))
    .query(async (opts) => {
      const { ctx, input } = opts;
      return searchAgents(input.query, ctx.user.id);
    }),
});
