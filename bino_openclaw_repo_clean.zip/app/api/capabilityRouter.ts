import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import {
  findAllCapabilities,
  findCapabilityById,
  findCapabilitiesByAgent,
  seedCapabilities,
  assignCapabilityToAgent,
  removeCapabilityFromAgent,
} from "./queries/capabilities";

export const capabilityRouter = createRouter({
  list: publicQuery.query(async () => findAllCapabilities()),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async (opts) => findCapabilityById(opts.input.id)),

  byAgent: authedQuery
    .input(z.object({ agentId: z.number() }))
    .query(async (opts) => findCapabilitiesByAgent(opts.input.agentId)),

  seed: publicQuery.mutation(async () => seedCapabilities()),

  assign: authedQuery
    .input(
      z.object({
        agentId: z.number(),
        capabilityId: z.number(),
        config: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => assignCapabilityToAgent(opts.input)),

  remove: authedQuery
    .input(z.object({ agentId: z.number(), capabilityId: z.number() }))
    .mutation(async (opts) => removeCapabilityFromAgent(opts.input.agentId, opts.input.capabilityId)),
});
