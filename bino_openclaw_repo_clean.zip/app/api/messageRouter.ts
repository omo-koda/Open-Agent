import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  findMessagesByAgent,
  findMessagesBySwarm,
  createMessage,
} from "./queries/messages";

export const messageRouter = createRouter({
  byAgent: authedQuery
    .input(z.object({ agentId: z.number() }))
    .query(async (opts) => findMessagesByAgent(opts.input.agentId)),

  bySwarm: authedQuery
    .input(z.object({ swarmId: z.number() }))
    .query(async (opts) => findMessagesBySwarm(opts.input.swarmId)),

  create: authedQuery
    .input(
      z.object({
        fromAgentId: z.number().optional(),
        toAgentId: z.number().optional(),
        swarmId: z.number().optional(),
        content: z.string().min(1),
        type: z.enum(["text", "image", "audio", "video", "command", "result", "broadcast"]).optional(),
        metadata: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => createMessage(opts.input)),
});
