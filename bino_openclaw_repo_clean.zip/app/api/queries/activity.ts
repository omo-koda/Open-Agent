import { getDb } from "./connection";
import { activityLogs } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export async function findActivityLogs(params?: {
  agentId?: number;
  swarmId?: number;
  userId?: number;
  limit?: number;
}) {
  const conditions = [];
  if (params?.agentId) conditions.push(eq(activityLogs.agentId, params.agentId));
  if (params?.swarmId) conditions.push(eq(activityLogs.swarmId, params.swarmId));
  if (params?.userId) conditions.push(eq(activityLogs.userId, params.userId));

  return getDb().query.activityLogs.findMany({
    where: conditions.length > 0 ? conditions[0] : undefined,
    orderBy: desc(activityLogs.createdAt),
    limit: params?.limit ?? 50,
    with: {
      agent: true,
      swarm: true,
      user: true,
    },
  });
}

export async function createActivityLog(data: {
  agentId?: number;
  swarmId?: number;
  userId?: number;
  action: string;
  details?: Record<string, unknown>;
}) {
  await getDb().insert(activityLogs).values({
    agentId: data.agentId ?? null,
    swarmId: data.swarmId ?? null,
    userId: data.userId ?? null,
    action: data.action,
    details: data.details ?? {},
  });
}
