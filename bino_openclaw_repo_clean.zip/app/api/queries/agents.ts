import { getDb } from "./connection";
import { agents } from "@db/schema";
import { eq, and, or, desc, like } from "drizzle-orm";

export async function findAgentsByUser(userId: number) {
  return getDb().query.agents.findMany({
    where: eq(agents.ownerId, userId),
    orderBy: desc(agents.updatedAt),
  });
}

export async function findPublicAgents() {
  return getDb().query.agents.findMany({
    where: eq(agents.isPublic, true),
    orderBy: desc(agents.updatedAt),
  });
}

export async function findAgentById(id: number) {
  return getDb().query.agents.findFirst({
    where: eq(agents.id, id),
    with: {
      capabilities: { with: { capability: true } },
      swarmAgents: { with: { swarm: true } },
    },
  });
}

export async function createAgent(data: {
  name: string;
  description?: string;
  model?: string;
  systemPrompt?: string;
  ownerId: number;
  thinkingMode?: boolean;
  lowLatency?: boolean;
  config?: Record<string, unknown>;
}) {
  const [{ id }] = await getDb()
    .insert(agents)
    .values({
      name: data.name,
      description: data.description ?? null,
      model: data.model ?? "gemini-2.5-pro",
      systemPrompt: data.systemPrompt ?? null,
      ownerId: data.ownerId,
      thinkingMode: data.thinkingMode ?? false,
      lowLatency: data.lowLatency ?? false,
      config: data.config ?? {},
    })
    .$returningId();
  return findAgentById(id);
}

export async function updateAgent(
  id: number,
  data: Partial<{
    name: string;
    description: string;
    model: string;
    systemPrompt: string;
    status: "idle" | "active" | "busy" | "offline" | "error";
    isPublic: boolean;
    thinkingMode: boolean;
    lowLatency: boolean;
    config: Record<string, unknown>;
  }>
) {
  await getDb()
    .update(agents)
    .set(data)
    .where(eq(agents.id, id));
  return findAgentById(id);
}

export async function deleteAgent(id: number) {
  await getDb().delete(agents).where(eq(agents.id, id));
}

export async function searchAgents(query: string, userId: number) {
  return getDb().query.agents.findMany({
    where: and(
      or(eq(agents.ownerId, userId), eq(agents.isPublic, true)),
      like(agents.name, `%${query}%`)
    ),
    orderBy: desc(agents.updatedAt),
  });
}
