import { getDb } from "./connection";
import { capabilities, agentCapabilities } from "@db/schema";
import { eq, and } from "drizzle-orm";

export async function findAllCapabilities() {
  return getDb().query.capabilities.findMany({
    orderBy: (capabilities, { asc }) => [asc(capabilities.category), asc(capabilities.name)],
  });
}

export async function findCapabilityById(id: number) {
  return getDb().query.capabilities.findFirst({
    where: eq(capabilities.id, id),
  });
}

export async function findCapabilitiesByAgent(agentId: number) {
  return getDb().query.agentCapabilities.findMany({
    where: eq(agentCapabilities.agentId, agentId),
    with: { capability: true },
  });
}

export async function seedCapabilities() {
  const caps = [
    { name: "high_thinking", displayName: "High Thinking", description: "Enable advanced reasoning and deep analysis", icon: "brain", category: "intelligence" as const, endpoint: "/api/capabilities/high-thinking", configSchema: { depth: "number", mode: "string" } },
    { name: "speech_to_text", displayName: "Speech to Text", description: "Transcribe audio to text in real-time", icon: "mic", category: "communication" as const, endpoint: "/api/capabilities/stt", configSchema: { language: "string", continuous: "boolean" } },
    { name: "video_library", displayName: "Video Library", description: "Analyze and manage video content", icon: "video", category: "media" as const, endpoint: "/api/capabilities/video", configSchema: { maxDuration: "number", quality: "string" } },
    { name: "low_latency", displayName: "Low Latency", description: "Add ultra-fast response mode", icon: "zap", category: "intelligence" as const, endpoint: "/api/capabilities/low-latency", configSchema: { priority: "number" } },
    { name: "document_scanner", displayName: "Document Scanner", description: "Analyze and extract data from images", icon: "scan", category: "data" as const, endpoint: "/api/capabilities/ocr", configSchema: { languages: "array", enhance: "boolean" } },
    { name: "aspect_ratio", displayName: "Aspect Ratio Control", description: "Control image and video aspect ratios", icon: "ratio", category: "media" as const, endpoint: "/api/capabilities/aspect-ratio", configSchema: { ratio: "string", cropMode: "string" } },
    { name: "video_spark", displayName: "Video Spark", description: "Generate video from text descriptions", icon: "sparkles", category: "creative" as const, endpoint: "/api/capabilities/video-gen", configSchema: { duration: "number", style: "string" } },
    { name: "voice_chat", displayName: "Voice Chat", description: "Add conversational voice interface", icon: "headphones", category: "communication" as const, endpoint: "/api/capabilities/voice-chat", configSchema: { voice: "string", speed: "number" } },
    { name: "gemini_intelligence", displayName: "Gemini Intelligence", description: "Add Gemini-powered reasoning", icon: "spark", category: "intelligence" as const, endpoint: "/api/capabilities/gemini", configSchema: { model: "string", temperature: "number" } },
    { name: "image_generation", displayName: "Image Generation", description: "Generate high-quality images from text", icon: "image", category: "creative" as const, endpoint: "/api/capabilities/image-gen", configSchema: { size: "string", style: "string" } },
    { name: "google_maps", displayName: "Google Maps", description: "Use Google Maps data and location services", icon: "map-pin", category: "data" as const, endpoint: "/api/capabilities/maps", configSchema: { region: "string", zoom: "number" } },
    { name: "google_search", displayName: "Google Search", description: "Use Google Search data", icon: "search", category: "data" as const, endpoint: "/api/capabilities/search", configSchema: { safeSearch: "boolean", region: "string" } },
    { name: "image_animation", displayName: "Image Animation", description: "Animate images into video", icon: "film", category: "creative" as const, endpoint: "/api/capabilities/animate", configSchema: { frames: "number", duration: "number" } },
    { name: "audio_spark", displayName: "Audio Spark", description: "Add voice conversations and TTS", icon: "audio-lines", category: "communication" as const, endpoint: "/api/capabilities/audio", configSchema: { voice: "string", emotion: "string" } },
    { name: "image_edit", displayName: "Image Edit", description: "Create and edit images with AI", icon: "paintbrush", category: "creative" as const, endpoint: "/api/capabilities/image-edit", configSchema: { mode: "string", strength: "number" } },
    { name: "text_to_speech", displayName: "Text to Speech", description: "Convert text to natural speech", icon: "volume-2", category: "communication" as const, endpoint: "/api/capabilities/tts", configSchema: { voice: "string", speed: "number", pitch: "number" } },
    { name: "music_generation", displayName: "Music Generation", description: "Generate music from descriptions", icon: "music", category: "creative" as const, endpoint: "/api/capabilities/music", configSchema: { genre: "string", duration: "number", tempo: "number" } },
  ];

  for (const cap of caps) {
    await getDb()
      .insert(capabilities)
      .values(cap)
      .onDuplicateKeyUpdate({ set: { displayName: cap.displayName, description: cap.description } });
  }
}

export async function assignCapabilityToAgent(data: {
  agentId: number;
  capabilityId: number;
  config?: Record<string, unknown>;
}) {
  await getDb()
    .insert(agentCapabilities)
    .values({
      agentId: data.agentId,
      capabilityId: data.capabilityId,
      config: data.config ?? {},
    })
    .onDuplicateKeyUpdate({
      set: { config: data.config ?? {}, isActive: true },
    });
}

export async function removeCapabilityFromAgent(agentId: number, capabilityId: number) {
  await getDb()
    .delete(agentCapabilities)
    .where(and(eq(agentCapabilities.agentId, agentId), eq(agentCapabilities.capabilityId, capabilityId)));
}
