import { getDb } from "./connection";
import { agentMessages } from "@db/schema";
import { eq, or, desc } from "drizzle-orm";

export async function findMessagesByAgent(agentId: number) {
  return getDb().query.agentMessages.findMany({
    where: or(eq(agentMessages.fromAgentId, agentId), eq(agentMessages.toAgentId, agentId)),
    orderBy: desc(agentMessages.createdAt),
    with: {
      fromAgent: true,
      toAgent: true,
    },
  });
}

export async function findMessagesBySwarm(swarmId: number) {
  return getDb().query.agentMessages.findMany({
    where: eq(agentMessages.swarmId, swarmId),
    orderBy: desc(agentMessages.createdAt),
    with: {
      fromAgent: true,
      toAgent: true,
    },
  });
}

export async function createMessage(data: {
  fromAgentId?: number;
  toAgentId?: number;
  swarmId?: number;
  content: string;
  type?: "text" | "image" | "audio" | "video" | "command" | "result" | "broadcast";
  metadata?: Record<string, unknown>;
}) {
  const [{ id }] = await getDb()
    .insert(agentMessages)
    .values({
      fromAgentId: data.fromAgentId ?? null,
      toAgentId: data.toAgentId ?? null,
      swarmId: data.swarmId ?? null,
      content: data.content,
      type: data.type ?? "text",
      metadata: data.metadata ?? {},
    })
    .$returningId();
  return getDb().query.agentMessages.findFirst({
    where: eq(agentMessages.id, id),
    with: { fromAgent: true, toAgent: true },
  });
}
