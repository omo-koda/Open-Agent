import { getDb } from "./connection";
import { agentShares } from "@db/schema";
import { eq, or } from "drizzle-orm";

export async function findSharesByAgent(agentId: number) {
  return getDb().query.agentShares.findMany({
    where: eq(agentShares.agentId, agentId),
    with: { sharedBy: true },
  });
}

export async function findSharesByUser(userId: number) {
  return getDb().query.agentShares.findMany({
    where: or(
      eq(agentShares.sharedByUserId, userId),
      eq(agentShares.sharedWithUserId, userId)
    ),
    with: { agent: true },
  });
}

export async function createShare(data: {
  agentId: number;
  sharedByUserId: number;
  sharedWithUserId?: number;
  permissionLevel?: "view" | "use" | "edit";
  shareToken?: string;
  isPublicShare?: boolean;
  expiresAt?: Date;
}) {
  const [{ id }] = await getDb()
    .insert(agentShares)
    .values({
      agentId: data.agentId,
      sharedByUserId: data.sharedByUserId,
      sharedWithUserId: data.sharedWithUserId ?? null,
      permissionLevel: data.permissionLevel ?? "view",
      shareToken: data.shareToken ?? null,
      isPublicShare: data.isPublicShare ?? false,
      expiresAt: data.expiresAt ?? null,
    })
    .$returningId();
  return getDb().query.agentShares.findFirst({
    where: eq(agentShares.id, id),
    with: { agent: true, sharedBy: true },
  });
}

export async function findShareByToken(token: string) {
  return getDb().query.agentShares.findFirst({
    where: eq(agentShares.shareToken, token),
    with: { agent: true, sharedBy: true },
  });
}

export async function deleteShare(id: number) {
  await getDb().delete(agentShares).where(eq(agentShares.id, id));
}
