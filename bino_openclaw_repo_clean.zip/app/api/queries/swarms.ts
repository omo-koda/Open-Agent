import { getDb } from "./connection";
import { swarms, swarmAgents } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function findSwarmsByUser(userId: number) {
  return getDb().query.swarms.findMany({
    where: eq(swarms.ownerId, userId),
    orderBy: desc(swarms.updatedAt),
    with: {
      swarmAgents: { with: { agent: true } },
    },
  });
}

export async function findSwarmById(id: number) {
  return getDb().query.swarms.findFirst({
    where: eq(swarms.id, id),
    with: {
      swarmAgents: { with: { agent: true } },
      messages: { orderBy: desc(swarmAgents.joinedAt) },
    },
  });
}

export async function createSwarm(data: {
  name: string;
  description?: string;
  ownerId: number;
  orchestrationMode?: "round_robin" | "hierarchical" | "democratic" | "competitive";
  config?: Record<string, unknown>;
}) {
  const [{ id }] = await getDb()
    .insert(swarms)
    .values({
      name: data.name,
      description: data.description ?? null,
      ownerId: data.ownerId,
      orchestrationMode: data.orchestrationMode ?? "round_robin",
      config: data.config ?? {},
    })
    .$returningId();
  return findSwarmById(id);
}

export async function updateSwarm(
  id: number,
  data: Partial<{
    name: string;
    description: string;
    status: "idle" | "active" | "paused" | "error";
    orchestrationMode: "round_robin" | "hierarchical" | "democratic" | "competitive";
    config: Record<string, unknown>;
  }>
) {
  await getDb().update(swarms).set(data).where(eq(swarms.id, id));
  return findSwarmById(id);
}

export async function deleteSwarm(id: number) {
  await getDb().delete(swarms).where(eq(swarms.id, id));
}

export async function addAgentToSwarm(data: {
  swarmId: number;
  agentId: number;
  role?: "leader" | "worker" | "observer" | "specialist";
  priority?: number;
}) {
  await getDb()
    .insert(swarmAgents)
    .values({
      swarmId: data.swarmId,
      agentId: data.agentId,
      role: data.role ?? "worker",
      priority: data.priority ?? 0,
    })
    .onDuplicateKeyUpdate({
      set: { role: data.role ?? "worker", priority: data.priority ?? 0 },
    });
}

export async function removeAgentFromSwarm(swarmId: number, agentId: number) {
  await getDb()
    .delete(swarmAgents)
    .where(and(eq(swarmAgents.swarmId, swarmId), eq(swarmAgents.agentId, agentId)));
}
