import { authRouter } from "./auth-router";
import { agentRouter } from "./agentRouter";
import { swarmRouter } from "./swarmRouter";
import { capabilityRouter } from "./capabilityRouter";
import { messageRouter } from "./messageRouter";
import { shareRouter } from "./shareRouter";
import { activityRouter } from "./activityRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  agent: agentRouter,
  swarm: swarmRouter,
  capability: capabilityRouter,
  message: messageRouter,
  share: shareRouter,
  activity: activityRouter,
});

export type AppRouter = typeof appRouter;
