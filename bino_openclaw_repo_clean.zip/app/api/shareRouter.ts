import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import {
  findSharesByAgent,
  findSharesByUser,
  createShare,
  findShareByToken,
  deleteShare,
} from "./queries/shares";

export const shareRouter = createRouter({
  listByAgent: authedQuery
    .input(z.object({ agentId: z.number() }))
    .query(async (opts) => findSharesByAgent(opts.input.agentId)),

  myShares: authedQuery.query(async (opts) => findSharesByUser(opts.ctx.user.id)),

  create: authedQuery
    .input(
      z.object({
        agentId: z.number(),
        sharedWithUserId: z.number().optional(),
        permissionLevel: z.enum(["view", "use", "edit"]).optional(),
        shareToken: z.string().optional(),
        isPublicShare: z.boolean().optional(),
        expiresAt: z.string().optional(),
      })
    )
    .mutation(async (opts) => {
      const { ctx, input } = opts;
      return createShare({
        ...input,
        sharedByUserId: ctx.user.id,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : undefined,
      });
    }),

  byToken: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async (opts) => findShareByToken(opts.input.token)),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async (opts) => deleteShare(opts.input.id)),
});
