import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  findSwarmsByUser,
  findSwarmById,
  createSwarm,
  updateSwarm,
  deleteSwarm,
  addAgentToSwarm,
  removeAgentFromSwarm,
} from "./queries/swarms";

export const swarmRouter = createRouter({
  list: authedQuery.query(async (opts) => findSwarmsByUser(opts.ctx.user.id)),

  byId: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async (opts) => findSwarmById(opts.input.id)),

  create: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        description: z.string().optional(),
        orchestrationMode: z.enum(["round_robin", "hierarchical", "democratic", "competitive"]).optional(),
        config: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => {
      const { ctx, input } = opts;
      return createSwarm({ ...input, ownerId: ctx.user.id });
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        status: z.enum(["idle", "active", "paused", "error"]).optional(),
        orchestrationMode: z.enum(["round_robin", "hierarchical", "democratic", "competitive"]).optional(),
        config: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async (opts) => {
      const { input } = opts;
      return updateSwarm(input.id, input);
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async (opts) => {
      const { input } = opts;
      return deleteSwarm(input.id);
    }),

  addAgent: authedQuery
    .input(
      z.object({
        swarmId: z.number(),
        agentId: z.number(),
        role: z.enum(["leader", "worker", "observer", "specialist"]).optional(),
        priority: z.number().optional(),
      })
    )
    .mutation(async (opts) => addAgentToSwarm(opts.input)),

  removeAgent: authedQuery
    .input(z.object({ swarmId: z.number(), agentId: z.number() }))
    .mutation(async (opts) => removeAgentFromSwarm(opts.input.swarmId, opts.input.agentId)),
});
