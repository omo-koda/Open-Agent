import { relations } from "drizzle-orm";
import {
  users,
  agents,
  swarms,
  swarmAgents,
  capabilities,
  agentCapabilities,
  agentMessages,
  agentShares,
  activityLogs,
  userSettings,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  agents: many(agents),
  swarms: many(swarms),
  settings: many(userSettings),
  activities: many(activityLogs),
  shares: many(agentShares),
}));

export const agentsRelations = relations(agents, ({ one, many }) => ({
  owner: one(users, { fields: [agents.ownerId], references: [users.id] }),
  swarmAgents: many(swarmAgents),
  capabilities: many(agentCapabilities),
  messagesSent: many(agentMessages, { relationName: "fromAgent" }),
  messagesReceived: many(agentMessages, { relationName: "toAgent" }),
  shares: many(agentShares),
  activities: many(activityLogs),
}));

export const swarmsRelations = relations(swarms, ({ one, many }) => ({
  owner: one(users, { fields: [swarms.ownerId], references: [users.id] }),
  swarmAgents: many(swarmAgents),
  messages: many(agentMessages),
  activities: many(activityLogs),
}));

export const swarmAgentsRelations = relations(swarmAgents, ({ one }) => ({
  swarm: one(swarms, { fields: [swarmAgents.swarmId], references: [swarms.id] }),
  agent: one(agents, { fields: [swarmAgents.agentId], references: [agents.id] }),
}));

export const capabilitiesRelations = relations(capabilities, ({ many }) => ({
  agentCapabilities: many(agentCapabilities),
}));

export const agentCapabilitiesRelations = relations(agentCapabilities, ({ one }) => ({
  agent: one(agents, { fields: [agentCapabilities.agentId], references: [agents.id] }),
  capability: one(capabilities, { fields: [agentCapabilities.capabilityId], references: [capabilities.id] }),
}));

export const agentMessagesRelations = relations(agentMessages, ({ one }) => ({
  fromAgent: one(agents, { fields: [agentMessages.fromAgentId], references: [agents.id] }),
  toAgent: one(agents, { fields: [agentMessages.toAgentId], references: [agents.id] }),
  swarm: one(swarms, { fields: [agentMessages.swarmId], references: [swarms.id] }),
}));

export const agentSharesRelations = relations(agentShares, ({ one }) => ({
  agent: one(agents, { fields: [agentShares.agentId], references: [agents.id] }),
  sharedBy: one(users, { fields: [agentShares.sharedByUserId], references: [users.id] }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  agent: one(agents, { fields: [activityLogs.agentId], references: [agents.id] }),
  swarm: one(swarms, { fields: [activityLogs.swarmId], references: [swarms.id] }),
  user: one(users, { fields: [activityLogs.userId], references: [users.id] }),
}));

export const userSettingsRelations = relations(userSettings, ({ one }) => ({
  user: one(users, { fields: [userSettings.userId], references: [users.id] }),
}));