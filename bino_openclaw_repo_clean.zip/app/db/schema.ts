import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  json,
  index,
} from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  agents: many(agents),
  swarms: many(swarms),
  settings: many(userSettings),
}));

export const agents = mysqlTable(
  "agents",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    avatar: text("avatar"),
    model: varchar("model", { length: 100 }).default("gemini-2.5-pro").notNull(),
    systemPrompt: text("systemPrompt"),
    status: mysqlEnum("status", ["idle", "active", "busy", "offline", "error"]).default("idle").notNull(),
    ownerId: bigint("ownerId", { mode: "number", unsigned: true }).notNull(),
    isPublic: boolean("isPublic").default(false).notNull(),
    config: json("config").$type<Record<string, unknown>>(),
    thinkingMode: boolean("thinkingMode").default(false).notNull(),
    lowLatency: boolean("lowLatency").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  },
  (table) => ({
    ownerIdx: index("agent_owner_idx").on(table.ownerId),
    statusIdx: index("agent_status_idx").on(table.status),
  })
);

export const agentsRelations = relations(agents, ({ one, many }) => ({
  owner: one(users, { fields: [agents.ownerId], references: [users.id] }),
  swarmAgents: many(swarmAgents),
  capabilities: many(agentCapabilities),
  messages: many(agentMessages),
  shares: many(agentShares),
  activities: many(activityLogs),
}));

export const swarms = mysqlTable(
  "swarms",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    status: mysqlEnum("status", ["idle", "active", "paused", "error"]).default("idle").notNull(),
    ownerId: bigint("ownerId", { mode: "number", unsigned: true }).notNull(),
    config: json("config").$type<Record<string, unknown>>(),
    orchestrationMode: mysqlEnum("orchestrationMode", ["round_robin", "hierarchical", "democratic", "competitive"]).default("round_robin").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  },
  (table) => ({
    ownerIdx: index("swarm_owner_idx").on(table.ownerId),
  })
);

export const swarmsRelations = relations(swarms, ({ one, many }) => ({
  owner: one(users, { fields: [swarms.ownerId], references: [users.id] }),
  swarmAgents: many(swarmAgents),
  messages: many(agentMessages),
  activities: many(activityLogs),
}));

export const swarmAgents = mysqlTable(
  "swarm_agents",
  {
    id: serial("id").primaryKey(),
    swarmId: bigint("swarmId", { mode: "number", unsigned: true }).notNull(),
    agentId: bigint("agentId", { mode: "number", unsigned: true }).notNull(),
    role: mysqlEnum("role", ["leader", "worker", "observer", "specialist"]).default("worker").notNull(),
    priority: int("priority").default(0).notNull(),
    joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  },
  (table) => ({
    swarmIdx: index("swarm_agents_swarm_idx").on(table.swarmId),
    agentIdx: index("swarm_agents_agent_idx").on(table.agentId),
  })
);

export const swarmAgentsRelations = relations(swarmAgents, ({ one }) => ({
  swarm: one(swarms, { fields: [swarmAgents.swarmId], references: [swarms.id] }),
  agent: one(agents, { fields: [swarmAgents.agentId], references: [agents.id] }),
}));

export const capabilities = mysqlTable(
  "capabilities",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull().unique(),
    displayName: varchar("displayName", { length: 255 }).notNull(),
    description: text("description"),
    icon: varchar("icon", { length: 100 }).notNull(),
    category: mysqlEnum("category", ["intelligence", "media", "communication", "data", "creative"]).notNull(),
    endpoint: varchar("endpoint", { length: 500 }),
    configSchema: json("configSchema").$type<Record<string, unknown>>(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    categoryIdx: index("capability_category_idx").on(table.category),
  })
);

export const capabilitiesRelations = relations(capabilities, ({ many }) => ({
  agentCapabilities: many(agentCapabilities),
}));

export const agentCapabilities = mysqlTable(
  "agent_capabilities",
  {
    id: serial("id").primaryKey(),
    agentId: bigint("agentId", { mode: "number", unsigned: true }).notNull(),
    capabilityId: bigint("capabilityId", { mode: "number", unsigned: true }).notNull(),
    config: json("config").$type<Record<string, unknown>>(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    agentIdx: index("agent_cap_agent_idx").on(table.agentId),
    capabilityIdx: index("agent_cap_capability_idx").on(table.capabilityId),
  })
);

export const agentCapabilitiesRelations = relations(agentCapabilities, ({ one }) => ({
  agent: one(agents, { fields: [agentCapabilities.agentId], references: [agents.id] }),
  capability: one(capabilities, { fields: [agentCapabilities.capabilityId], references: [capabilities.id] }),
}));

export const agentMessages = mysqlTable(
  "agent_messages",
  {
    id: serial("id").primaryKey(),
    fromAgentId: bigint("fromAgentId", { mode: "number", unsigned: true }),
    toAgentId: bigint("toAgentId", { mode: "number", unsigned: true }),
    swarmId: bigint("swarmId", { mode: "number", unsigned: true }),
    content: text("content").notNull(),
    type: mysqlEnum("type", ["text", "image", "audio", "video", "command", "result", "broadcast"]).default("text").notNull(),
    metadata: json("metadata").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    fromIdx: index("msg_from_idx").on(table.fromAgentId),
    toIdx: index("msg_to_idx").on(table.toAgentId),
    swarmIdx: index("msg_swarm_idx").on(table.swarmId),
    createdIdx: index("msg_created_idx").on(table.createdAt),
  })
);

export const agentMessagesRelations = relations(agentMessages, ({ one }) => ({
  fromAgent: one(agents, { fields: [agentMessages.fromAgentId], references: [agents.id] }),
  toAgent: one(agents, { fields: [agentMessages.toAgentId], references: [agents.id] }),
  swarm: one(swarms, { fields: [agentMessages.swarmId], references: [swarms.id] }),
}));

export const agentShares = mysqlTable(
  "agent_shares",
  {
    id: serial("id").primaryKey(),
    agentId: bigint("agentId", { mode: "number", unsigned: true }).notNull(),
    sharedByUserId: bigint("sharedByUserId", { mode: "number", unsigned: true }).notNull(),
    sharedWithUserId: bigint("sharedWithUserId", { mode: "number", unsigned: true }),
    permissionLevel: mysqlEnum("permissionLevel", ["view", "use", "edit"]).default("view").notNull(),
    shareToken: varchar("shareToken", { length: 255 }).unique(),
    isPublicShare: boolean("isPublicShare").default(false).notNull(),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    agentIdx: index("share_agent_idx").on(table.agentId),
    tokenIdx: index("share_token_idx").on(table.shareToken),
  })
);

export const agentSharesRelations = relations(agentShares, ({ one }) => ({
  agent: one(agents, { fields: [agentShares.agentId], references: [agents.id] }),
  sharedBy: one(users, { fields: [agentShares.sharedByUserId], references: [users.id] }),
}));

export const activityLogs = mysqlTable(
  "activity_logs",
  {
    id: serial("id").primaryKey(),
    agentId: bigint("agentId", { mode: "number", unsigned: true }),
    swarmId: bigint("swarmId", { mode: "number", unsigned: true }),
    userId: bigint("userId", { mode: "number", unsigned: true }),
    action: varchar("action", { length: 100 }).notNull(),
    details: json("details").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    agentIdx: index("activity_agent_idx").on(table.agentId),
    swarmIdx: index("activity_swarm_idx").on(table.swarmId),
    userIdx: index("activity_user_idx").on(table.userId),
    createdIdx: index("activity_created_idx").on(table.createdAt),
  })
);

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  agent: one(agents, { fields: [activityLogs.agentId], references: [agents.id] }),
  swarm: one(swarms, { fields: [activityLogs.swarmId], references: [swarms.id] }),
  user: one(users, { fields: [activityLogs.userId], references: [users.id] }),
}));

export const userSettings = mysqlTable(
  "user_settings",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull().unique(),
    theme: mysqlEnum("theme", ["light", "dark", "system", "neon", "holographic"]).default("dark").notNull(),
    notifications: boolean("notifications").default(true).notNull(),
    defaultAgentConfig: json("defaultAgentConfig").$type<Record<string, unknown>>(),
    dashboardLayout: json("dashboardLayout").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  },
  (table) => ({
    userIdx: index("settings_user_idx").on(table.userId),
  })
);

export const userSettingsRelations = relations(userSettings, ({ one }) => ({
  user: one(users, { fields: [userSettings.userId], references: [users.id] }),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;
export type Swarm = typeof swarms.$inferSelect;
export type InsertSwarm = typeof swarms.$inferInsert;
export type SwarmAgent = typeof swarmAgents.$inferSelect;
export type Capability = typeof capabilities.$inferSelect;
export type InsertCapability = typeof capabilities.$inferInsert;
export type AgentCapability = typeof agentCapabilities.$inferSelect;
export type AgentMessage = typeof agentMessages.$inferSelect;
export type AgentShare = typeof agentShares.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type UserSetting = typeof userSettings.$inferSelect;
export type InsertUserSetting = typeof userSettings.$inferInsert;
