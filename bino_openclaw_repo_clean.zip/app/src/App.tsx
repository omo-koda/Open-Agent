import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Agents from './pages/Agents'
import Swarms from './pages/Swarms'
import Capabilities from './pages/Capabilities'
import Share from './pages/Share'
import Activity from './pages/Activity'
import Claw from './pages/Claw'
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/agents" element={<Agents />} />
      <Route path="/swarms" element={<Swarms />} />
      <Route path="/capabilities" element={<Capabilities />} />
      <Route path="/share" element={<Share />} />
      <Route path="/activity" element={<Activity />} />
      <Route path="/claw" element={<Claw />} />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
