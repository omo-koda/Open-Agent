import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Activity,
  Bot,
  Hexagon,
  Zap,
  Clock,
  TrendingUp,
  BarChart3,
  Radio,
  ArrowUpRight,
} from "lucide-react";
import { useMemo } from "react";

function ActivityTimeline() {
  const { data: logs, isLoading } = trpc.activity.list.useQuery({ limit: 50 });

  const grouped = useMemo(() => {
    const groups: Record<string, typeof logs> = {};
    logs?.forEach((log) => {
      const date = new Date(log.createdAt).toLocaleDateString();
      if (!groups[date]) groups[date] = [];
      groups[date].push(log);
    });
    return groups;
  }, [logs]);

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="glass rounded-xl p-4 h-20 animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([date, dayLogs]) => (
        <div key={date}>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 sticky top-0">
            {date}
          </h3>
          <div className="space-y-2">
            {dayLogs?.map((log, i) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="glass rounded-lg p-3 flex items-center gap-3 hover:bg-white/10 transition-all"
              >
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                  {log.agent ? (
                    <Bot className="h-4 w-4 text-primary" />
                  ) : log.swarm ? (
                    <Hexagon className="h-4 w-4 text-accent" />
                  ) : (
                    <Zap className="h-4 w-4 text-primary" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground">{log.action}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {log.agent?.name ?? log.swarm?.name ?? "System"} ·{" "}
                    {new Date(log.createdAt).toLocaleTimeString()}
                  </p>
                </div>
                {log.details && Object.keys(log.details).length > 0 && (
                  <div className="text-[10px] text-muted-foreground bg-white/5 px-2 py-1 rounded">
                    {JSON.stringify(log.details).slice(0, 30)}...
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      ))}
      {!logs?.length && (
        <p className="text-sm text-muted-foreground text-center py-12">No activity recorded yet</p>
      )}
    </div>
  );
}

function StatsCards() {
  const { data: logs } = trpc.activity.list.useQuery({ limit: 100 });
  const { data: agents } = trpc.agent.list.useQuery();
  const { data: swarms } = trpc.swarm.list.useQuery();

  const today = new Date().toLocaleDateString();
  const todayActivity = logs?.filter(
    (l) => new Date(l.createdAt).toLocaleDateString() === today
  ).length ?? 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <Activity className="h-4 w-4 text-primary" />
          <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
            <ArrowUpRight className="h-3 w-3" /> Live
          </span>
        </div>
        <p className="text-2xl font-bold text-foreground">{todayActivity}</p>
        <p className="text-[10px] text-muted-foreground">Today&apos;s Activity</p>
      </div>

      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <Bot className="h-4 w-4 text-accent" />
          <span className="text-[10px] text-muted-foreground">Total</span>
        </div>
        <p className="text-2xl font-bold text-foreground">{agents?.length ?? 0}</p>
        <p className="text-[10px] text-muted-foreground">Active Agents</p>
      </div>

      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <Hexagon className="h-4 w-4 text-emerald-400" />
          <span className="text-[10px] text-muted-foreground">Total</span>
        </div>
        <p className="text-2xl font-bold text-foreground">{swarms?.length ?? 0}</p>
        <p className="text-[10px] text-muted-foreground">Running Swarms</p>
      </div>

      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <Clock className="h-4 w-4 text-amber-400" />
          <span className="text-[10px] text-muted-foreground">All time</span>
        </div>
        <p className="text-2xl font-bold text-foreground">{logs?.length ?? 0}</p>
        <p className="text-[10px] text-muted-foreground">Total Events</p>
      </div>
    </div>
  );
}

function AgentActivityChart() {
  const { data: logs } = trpc.activity.list.useQuery({ limit: 100 });

  const agentCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    logs?.forEach((log) => {
      const name = log.agent?.name ?? "System";
      counts[name] = (counts[name] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [logs]);

  const maxCount = Math.max(...agentCounts.map(([, c]) => c), 1);

  return (
    <div className="glass rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Agent Activity Distribution</h3>
      </div>
      <div className="space-y-3">
        {agentCounts.map(([name, count]) => (
          <div key={name} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-foreground">{name}</span>
              <span className="text-muted-foreground">{count}</span>
            </div>
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(count / maxCount) * 100}%` }}
                transition={{ duration: 0.5 }}
                className="h-full rounded-full bg-primary/60"
              />
            </div>
          </div>
        ))}
        {!agentCounts.length && (
          <p className="text-xs text-muted-foreground text-center py-4">No data yet</p>
        )}
      </div>
    </div>
  );
}

function RecentTrends() {
  const { data: logs } = trpc.activity.list.useQuery({ limit: 50 });

  const actionCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    logs?.forEach((log) => {
      counts[log.action] = (counts[log.action] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [logs]);

  return (
    <div className="glass rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-4 w-4 text-accent" />
        <h3 className="text-sm font-semibold text-foreground">Top Actions</h3>
      </div>
      <div className="space-y-2">
        {actionCounts.map(([action, count], i) => (
          <div key={action} className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-4">{i + 1}</span>
            <div className="flex-1">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-foreground">{action}</span>
                <span className="text-muted-foreground">{count}</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(count / (actionCounts[0]?.[1] ?? 1)) * 100}%` }}
                  transition={{ duration: 0.5 }}
                  className="h-full rounded-full bg-accent/60"
                />
              </div>
            </div>
          </div>
        ))}
        {!actionCounts.length && (
          <p className="text-xs text-muted-foreground text-center py-4">No data yet</p>
        )}
      </div>
    </div>
  );
}

export default function ActivityPage() {
  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground neon-text">Activity & Analytics</h1>
          <p className="text-sm text-muted-foreground">Monitor your agent ecosystem in real-time</p>
        </div>

        <StatsCards />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
          <div className="lg:col-span-2">
            <ActivityTimeline />
          </div>
          <div className="space-y-4">
            <AgentActivityChart />
            <RecentTrends />

            <div className="glass rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Radio className="h-4 w-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-foreground">System Status</h3>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Database</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Connected
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Auth</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Active
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">API</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Online
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
}
