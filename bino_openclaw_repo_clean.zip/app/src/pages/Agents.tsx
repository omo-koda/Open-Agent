import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bot,
  Plus,
  Search,
  Brain,
  Zap,
  Mic,
  Video,
  ImageIcon,
  MapPin,
  Music,
  Volume2,
  Search as SearchIcon,
  Scan,
  Sparkles,
  Trash2,
  Share2,
  Check,
  Settings,
} from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const iconMap: Record<string, React.ElementType> = {
  brain: Brain,
  mic: Mic,
  video: Video,
  zap: Zap,
  scan: Scan,
  ratio: ImageIcon,
  sparkles: Sparkles,
  headphones: Volume2,
  spark: Zap,
  image: ImageIcon,
  "map-pin": MapPin,
  search: SearchIcon,
  film: Video,
  "audio-lines": Volume2,
  paintbrush: Sparkles,
  "volume-2": Volume2,
  music: Music,
};

function CreateAgentDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const utils = trpc.useUtils();
  const createAgent = trpc.agent.create.useMutation({
    onSuccess: () => {
      utils.agent.list.invalidate();
      onClose();
    },
  });

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [model, setModel] = useState("gemini-2.5-pro");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [thinkingMode, setThinkingMode] = useState(false);
  const [lowLatency, setLowLatency] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAgent.mutate({
      name,
      description,
      model,
      systemPrompt,
      thinkingMode,
      lowLatency,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass border-white/10 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Plus className="h-5 w-5 text-primary" />
            Create New Agent
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div>
            <Label className="text-foreground">Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Agent name..."
              className="bg-white/5 border-white/10 text-foreground mt-1"
              required
            />
          </div>
          <div>
            <Label className="text-foreground">Description</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this agent do?"
              className="bg-white/5 border-white/10 text-foreground mt-1"
            />
          </div>
          <div>
            <Label className="text-foreground">Model</Label>
            <Input
              value={model}
              onChange={(e) => setModel(e.target.value)}
              placeholder="gemini-2.5-pro"
              className="bg-white/5 border-white/10 text-foreground mt-1"
            />
          </div>
          <div>
            <Label className="text-foreground">System Prompt</Label>
            <Textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              placeholder="Instructions for the agent..."
              className="bg-white/5 border-white/10 text-foreground mt-1"
              rows={3}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Switch checked={thinkingMode} onCheckedChange={setThinkingMode} />
              <Label className="text-foreground text-sm">High Thinking</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={lowLatency} onCheckedChange={setLowLatency} />
              <Label className="text-foreground text-sm">Low Latency</Label>
            </div>
          </div>
          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90"
            disabled={createAgent.isPending}
          >
            {createAgent.isPending ? "Creating..." : "Create Agent"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AgentCard({
  agent,
  onDelete,
}: {
  agent: { id: number; name: string; description: string | null; status: string; model: string; thinkingMode: boolean; lowLatency: boolean };
  onDelete: (id: number) => void;
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { data: caps } = trpc.capability.byAgent.useQuery({ agentId: agent.id });

  const statusColors: Record<string, string> = {
    idle: "bg-white/10 text-muted-foreground",
    active: "bg-emerald-500/20 text-emerald-400",
    busy: "bg-amber-500/20 text-amber-400",
    offline: "bg-red-500/20 text-red-400",
    error: "bg-red-500/20 text-red-400",
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      whileHover={{ y: -4 }}
      className="glass rounded-xl overflow-hidden hover:neon-glow transition-all"
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{agent.name}</h3>
              <p className="text-[10px] text-muted-foreground">{agent.model}</p>
            </div>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors[agent.status] ?? statusColors.idle}`}>
            {agent.status}
          </span>
        </div>

        {agent.description && (
          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{agent.description}</p>
        )}

        <div className="flex items-center gap-2 mt-3">
          {agent.thinkingMode && (
            <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded flex items-center gap-1">
              <Brain className="h-3 w-3" /> Thinking
            </span>
          )}
          {agent.lowLatency && (
            <span className="text-[10px] bg-accent/20 text-accent px-1.5 py-0.5 rounded flex items-center gap-1">
              <Zap className="h-3 w-3" /> Fast
            </span>
          )}
        </div>

        {caps && caps.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {caps.map((ac) => {
              const Icon = iconMap[ac.capability.icon] ?? Sparkles;
              return (
                <span
                  key={ac.capability.id}
                  className="text-[10px] bg-white/5 text-muted-foreground px-1.5 py-0.5 rounded flex items-center gap-1"
                >
                  <Icon className="h-2.5 w-2.5" />
                  {ac.capability.displayName}
                </span>
              );
            })}
          </div>
        )}

        <div className="flex items-center gap-1 mt-3 pt-3 border-t border-white/5">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-white/5 transition-colors text-xs text-muted-foreground"
          >
            <Settings className="h-3 w-3" />
            Configure
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/5 transition-colors text-muted-foreground">
            <Share2 className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={() => onDelete(agent.id)}
            className="p-1.5 rounded-lg hover:bg-red-500/10 transition-colors text-red-400"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden border-t border-white/5"
          >
            <div className="p-4 space-y-3">
              <CapabilityAssigner agentId={agent.id} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function CapabilityAssigner({ agentId }: { agentId: number }) {
  const utils = trpc.useUtils();
  const { data: allCaps } = trpc.capability.list.useQuery();
  const { data: agentCaps } = trpc.capability.byAgent.useQuery({ agentId });
  const assign = trpc.capability.assign.useMutation({
    onSuccess: () => {
      utils.capability.byAgent.invalidate({ agentId });
    },
  });
  const remove = trpc.capability.remove.useMutation({
    onSuccess: () => {
      utils.capability.byAgent.invalidate({ agentId });
    },
  });

  const assignedIds = new Set(agentCaps?.map((ac) => ac.capabilityId) ?? []);

  return (
    <div className="space-y-2">
      <p className="text-xs font-medium text-foreground">Capabilities</p>
      <div className="grid grid-cols-2 gap-1.5">
        {allCaps?.map((cap) => {
          const isAssigned = assignedIds.has(cap.id);
          const Icon = iconMap[cap.icon] ?? Sparkles;
          return (
            <button
              key={cap.id}
              onClick={() => {
                if (isAssigned) {
                  remove.mutate({ agentId, capabilityId: cap.id });
                } else {
                  assign.mutate({ agentId, capabilityId: cap.id });
                }
              }}
              className={`flex items-center gap-2 p-2 rounded-lg text-left text-xs transition-all ${
                isAssigned
                  ? "bg-primary/20 text-primary border border-primary/30"
                  : "bg-white/5 text-muted-foreground hover:bg-white/10 border border-transparent"
              }`}
            >
              <Icon className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{cap.displayName}</span>
              {isAssigned ? (
                <Check className="h-3 w-3 ml-auto shrink-0" />
              ) : (
                <Plus className="h-3 w-3 ml-auto shrink-0 opacity-50" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function Agents() {
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const utils = trpc.useUtils();
  const { data: agents, isLoading } = trpc.agent.list.useQuery();
  const deleteAgent = trpc.agent.delete.useMutation({
    onSuccess: () => utils.agent.list.invalidate(),
  });

  const filtered = agents?.filter((a) =>
    a.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground neon-text">Agent Nexus</h1>
            <p className="text-sm text-muted-foreground">Create and manage your AI agents</p>
          </div>
          <Button
            onClick={() => setCreateOpen(true)}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Agent
          </Button>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search agents..."
            className="pl-10 bg-white/5 border-white/10 text-foreground"
          />
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="glass rounded-xl p-4 h-40 animate-pulse" />
            ))}
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence>
              {filtered?.map((agent) => (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  onDelete={(id) => deleteAgent.mutate({ id })}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}

        {!filtered?.length && !isLoading && (
          <div className="text-center py-16">
            <Bot className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No agents found. Create your first agent!</p>
          </div>
        )}

        <CreateAgentDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      </div>
    </AuthLayout>
  );
}
