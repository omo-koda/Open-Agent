import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Brain,
  Mic,
  Video,
  Zap,
  Scan,
  Image,
  Sparkles,
  Volume2,
  MapPin,
  Search,
  Music,
  Check,
  X,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";

const iconMap: Record<string, React.ElementType> = {
  brain: Brain,
  mic: Mic,
  video: Video,
  zap: Zap,
  scan: Scan,
  ratio: Image,
  sparkles: Sparkles,
  headphones: Volume2,
  spark: Zap,
  image: Image,
  "map-pin": MapPin,
  search: Search,
  film: Video,
  "audio-lines": Volume2,
  paintbrush: Sparkles,
  "volume-2": Volume2,
  music: Music,
};

const categoryColors: Record<string, string> = {
  intelligence: "from-cyan-500/20 to-blue-500/20 border-cyan-500/30",
  media: "from-purple-500/20 to-pink-500/20 border-purple-500/30",
  communication: "from-emerald-500/20 to-teal-500/20 border-emerald-500/30",
  data: "from-amber-500/20 to-orange-500/20 border-amber-500/30",
  creative: "from-rose-500/20 to-red-500/20 border-rose-500/30",
};

function CapabilityDetail({ cap, onClose }: { cap: { id: number; name: string; displayName: string; description: string | null; icon: string; category: string; endpoint: string | null; isActive: boolean; configSchema: Record<string, unknown> | null }; onClose: () => void }) {
  const Icon = iconMap[cap.icon] ?? Sparkles;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass rounded-2xl p-6 max-w-lg w-full border border-white/10">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg hover:bg-white/10 transition-colors"
        >
          <X className="h-4 w-4 text-muted-foreground" />
        </button>

        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center">
            <Icon className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">{cap.displayName}</h2>
            <span className="text-xs text-muted-foreground uppercase tracking-wider">{cap.category}</span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-4">{cap.description}</p>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
            <span className="text-xs text-muted-foreground">Status</span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${cap.isActive ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
              {cap.isActive ? "Active" : "Inactive"}
            </span>
          </div>

          {cap.endpoint && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
              <span className="text-xs text-muted-foreground">Endpoint</span>
              <span className="text-xs text-foreground font-mono">{cap.endpoint}</span>
            </div>
          )}

          {cap.configSchema && Object.keys(cap.configSchema).length > 0 && (
            <div className="p-3 rounded-lg bg-white/5">
              <span className="text-xs text-muted-foreground">Configuration Schema</span>
              <pre className="text-[10px] text-foreground mt-1 font-mono overflow-x-auto">
                {JSON.stringify(cap.configSchema, null, 2)}
              </pre>
            </div>
          )}
        </div>

        <div className="mt-6 flex gap-2">
          <button className="flex-1 py-2.5 rounded-lg bg-primary/20 text-primary text-sm font-medium hover:bg-primary/30 transition-colors flex items-center justify-center gap-2">
            <Check className="h-4 w-4" />
            Enable
          </button>
          <button className="flex-1 py-2.5 rounded-lg bg-white/5 text-foreground text-sm font-medium hover:bg-white/10 transition-colors flex items-center justify-center gap-2">
            <ArrowRight className="h-4 w-4" />
            Test
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function Capabilities() {
  const { data: capabilities, isLoading } = trpc.capability.list.useQuery();
  const [selectedCap, setSelectedCap] = useState<NonNullable<typeof capabilities>[number] | null>(null);

  const categories = [...new Set(capabilities?.map((c) => c.category) ?? [])];

  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground neon-text">Capability Hub</h1>
          <p className="text-sm text-muted-foreground">All available AI capabilities and services</p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="glass rounded-xl p-6 h-48 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-8">
            {categories.map((category) => {
              const caps = capabilities?.filter((c) => c.category === category) ?? [];
              return (
                <div key={category}>
                  <h2 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${category === "intelligence" ? "bg-cyan-400" : category === "media" ? "bg-purple-400" : category === "communication" ? "bg-emerald-400" : category === "data" ? "bg-amber-400" : "bg-rose-400"}`} />
                    {category}
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {caps.map((cap) => {
                      const Icon = iconMap[cap.icon] ?? Sparkles;
                      return (
                        <motion.div
                          key={cap.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          whileHover={{ scale: 1.02, y: -2 }}
                          onClick={() => setSelectedCap(cap)}
                          className={`glass rounded-xl p-5 cursor-pointer hover:neon-glow transition-all bg-gradient-to-br ${categoryColors[category] ?? "from-white/5 to-white/10 border-white/10"}`}
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                              <Icon className="h-5 w-5 text-foreground" />
                            </div>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full ${cap.isActive ? "bg-emerald-500/20 text-emerald-400" : "bg-white/10 text-muted-foreground"}`}>
                              {cap.isActive ? "Ready" : "Offline"}
                            </span>
                          </div>
                          <h3 className="text-sm font-semibold text-foreground mb-1">{cap.displayName}</h3>
                          <p className="text-xs text-muted-foreground line-clamp-2">{cap.description}</p>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedCap && (
        <CapabilityDetail cap={selectedCap} onClose={() => setSelectedCap(null)} />
      )}
    </AuthLayout>
  );
}
