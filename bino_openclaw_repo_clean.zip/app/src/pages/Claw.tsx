import AuthLayout from "@/components/AuthLayout";
import { motion } from "framer-motion";
import { Zap, ExternalLink, Maximize2, Minimize2, RefreshCw } from "lucide-react";
import { useState, useRef } from "react";

export default function Claw() {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const reload = () => {
    if (iframeRef.current) {
      iframeRef.current.src = iframeRef.current.src;
    }
  };

  return (
    <AuthLayout>
      <div className="max-w-full mx-auto h-[calc(100vh-2rem)]">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl overflow-hidden h-full flex flex-col"
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <Zap className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h1 className="text-sm font-semibold text-foreground">OpenClaw AI</h1>
                <p className="text-[10px] text-muted-foreground">Embedded Agent Interface</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={reload}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-muted-foreground"
                title="Reload"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-muted-foreground"
                title={isFullscreen ? "Collapse" : "Expand"}
              >
                {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </button>
              <a
                href="https://openclaw.ai/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-muted-foreground"
                title="Open in new tab"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div className="flex-1 overflow-hidden">
            <iframe
              ref={iframeRef}
              src="https://openclaw.ai/"
              className="w-full h-full border-0"
              title="OpenClaw AI"
              allow="microphone; camera; clipboard-write; clipboard-read; display-capture"
              sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-downloads"
            />
          </div>
        </motion.div>
      </div>
    </AuthLayout>
  );
}
