import { useAuth } from "@/hooks/useAuth";
import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Bot,
  Hexagon,
  Sparkles,
  Activity,
  Share2,
  Zap,
  Brain,
  Mic,
  Video,
  Image,
  MapPin,
  Music,
  Volume2,
  Search,
  Scan,
  ArrowUpRight,
  Radio,
  MessageSquare,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  show: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: "spring" as const, stiffness: 200, damping: 20 },
  },
};

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <motion.div
      variants={itemVariants}
      className="glass rounded-xl p-4 flex items-center gap-4 hover:bg-white/10 transition-all cursor-pointer group"
    >
      <div
        className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}
      >
        <Icon className="h-5 w-5 text-white" />
      </div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
      <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity ml-auto" />
    </motion.div>
  );
}

function CapabilityTile({
  icon: Icon,
  label,
  status,
  color,
}: {
  icon: React.ElementType;
  label: string;
  status: string;
  color: string;
}) {
  return (
    <motion.div
      variants={itemVariants}
      whileHover={{ scale: 1.03, y: -2 }}
      className="glass rounded-xl p-4 flex flex-col items-center gap-2 text-center hover:neon-glow transition-all cursor-pointer"
    >
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${color}`}>
        <Icon className="h-5 w-5 text-white" />
      </div>
      <span className="text-sm font-medium text-foreground">{label}</span>
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
        {status}
      </span>
    </motion.div>
  );
}

function ActivityFeed() {
  const { data: activities } = trpc.activity.list.useQuery({ limit: 10 });

  return (
    <motion.div
      variants={itemVariants}
      className="glass rounded-xl p-4 h-full"
    >
      <div className="flex items-center gap-2 mb-4">
        <Activity className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Live Activity</h3>
        <div className="ml-auto flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] text-emerald-400">LIVE</span>
        </div>
      </div>
      <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
        {activities?.map((log, i) => (
          <motion.div
            key={log.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <Zap className="h-3 w-3 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground truncate">
                {log.action}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {log.agent?.name ?? "System"} · {new Date(log.createdAt).toLocaleTimeString()}
              </p>
            </div>
          </motion.div>
        ))}
        {!activities?.length && (
          <p className="text-xs text-muted-foreground text-center py-8">No activity yet</p>
        )}
      </div>
    </motion.div>
  );
}

function SwarmVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions] = useState({ width: 300, height: 200 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = dimensions.width * dpr;
    canvas.height = dimensions.height * dpr;
    ctx.scale(dpr, dpr);

    const nodes = Array.from({ length: 6 }, () => ({
      x: Math.random() * dimensions.width,
      y: Math.random() * dimensions.height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      radius: 4 + Math.random() * 4,
      hue: 180 + Math.random() * 100,
    }));

    let animId: number;
    const animate = () => {
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);

      nodes.forEach((node) => {
        node.x += node.vx;
        node.y += node.vy;
        if (node.x < 0 || node.x > dimensions.width) node.vx *= -1;
        if (node.y < 0 || node.y > dimensions.height) node.vy *= -1;
      });

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            const alpha = (1 - dist / 120) * 0.3;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = `hsla(190, 80%, 60%, ${alpha})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }

      nodes.forEach((node) => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${node.hue}, 80%, 60%, 0.8)`;
        ctx.shadowColor = `hsla(${node.hue}, 80%, 60%, 0.5)`;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius + 4, 0, Math.PI * 2);
        ctx.strokeStyle = `hsla(${node.hue}, 80%, 60%, 0.2)`;
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      animId = requestAnimationFrame(animate);
    };

    animate();
    return () => cancelAnimationFrame(animId);
  }, [dimensions]);

  return (
    <motion.div variants={itemVariants} className="glass rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Hexagon className="h-4 w-4 text-accent" />
          <h3 className="text-sm font-semibold text-foreground">Swarm Network</h3>
        </div>
        <span className="text-[10px] text-accent bg-accent/10 px-2 py-0.5 rounded-full">
          6 Active Nodes
        </span>
      </div>
      <canvas
        ref={canvasRef}
        style={{ width: dimensions.width, height: dimensions.height }}
        className="w-full rounded-lg"
      />
    </motion.div>
  );
}

function OpenClawEmbed() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      variants={itemVariants}
      className={`glass rounded-xl overflow-hidden transition-all duration-500 ${isExpanded ? "col-span-2 row-span-2" : ""}`}
    >
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-primary/20 flex items-center justify-center">
            <Zap className="h-3.5 w-3.5 text-primary" />
          </div>
          <h3 className="text-sm font-semibold text-foreground">OpenClaw AI</h3>
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-xs text-primary hover:text-primary/80 transition-colors"
        >
          {isExpanded ? "Collapse" : "Expand"}
        </button>
      </div>
      <iframe
        src="https://openclaw.ai/"
        className="w-full border-0"
        style={{ height: isExpanded ? "calc(100vh - 200px)" : "400px" }}
        title="OpenClaw AI"
        allow="microphone; camera; clipboard-write; clipboard-read"
      />
    </motion.div>
  );
}

function QuickActions() {
  return (
    <motion.div variants={itemVariants} className="glass rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Radio className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Quick Actions</h3>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: "New Agent", icon: Bot, color: "bg-primary/20 text-primary" },
          { label: "Create Swarm", icon: Hexagon, color: "bg-accent/20 text-accent" },
          { label: "Generate Image", icon: Image, color: "bg-emerald-500/20 text-emerald-400" },
          { label: "Voice Chat", icon: Mic, color: "bg-amber-500/20 text-amber-400" },
        ].map((action) => (
          <button
            key={action.label}
            className="flex items-center gap-2 p-2.5 rounded-lg hover:bg-white/10 transition-all text-left group"
          >
            <div className={`w-7 h-7 rounded-md flex items-center justify-center ${action.color}`}>
              <action.icon className="h-3.5 w-3.5" />
            </div>
            <span className="text-xs font-medium text-foreground group-hover:text-primary transition-colors">
              {action.label}
            </span>
          </button>
        ))}
      </div>
    </motion.div>
  );
}

function RecentAgents() {
  const { data: agents } = trpc.agent.list.useQuery();

  return (
    <motion.div variants={itemVariants} className="glass rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Bot className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Recent Agents</h3>
        </div>
        <span className="text-[10px] text-muted-foreground">{agents?.length ?? 0} total</span>
      </div>
      <div className="space-y-2">
        {agents?.slice(0, 5).map((agent) => (
          <div
            key={agent.id}
            className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <Bot className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground truncate">{agent.name}</p>
              <p className="text-[10px] text-muted-foreground">{agent.model}</p>
            </div>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                agent.status === "active"
                  ? "bg-emerald-500/20 text-emerald-400"
                  : agent.status === "busy"
                  ? "bg-amber-500/20 text-amber-400"
                  : "bg-white/10 text-muted-foreground"
              }`}
            >
              {agent.status}
            </span>
          </div>
        ))}
        {!agents?.length && (
          <p className="text-xs text-muted-foreground text-center py-6">No agents yet</p>
        )}
      </div>
    </motion.div>
  );
}

function MessageStream() {
  const { data: messages } = trpc.message.bySwarm.useQuery({ swarmId: 1 });

  return (
    <motion.div variants={itemVariants} className="glass rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <MessageSquare className="h-4 w-4 text-accent" />
        <h3 className="text-sm font-semibold text-foreground">Agent Conversations</h3>
      </div>
      <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1">
        {messages?.slice(0, 5).map((msg) => (
          <div key={msg.id} className="flex gap-2 p-2 rounded-lg bg-white/5">
            <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
              <span className="text-[8px] text-primary font-bold">
                {msg.fromAgent?.name?.charAt(0) ?? "?"}
              </span>
            </div>
            <div>
              <p className="text-[10px] text-primary font-medium">{msg.fromAgent?.name ?? "Unknown"}</p>
              <p className="text-xs text-foreground line-clamp-2">{msg.content}</p>
            </div>
          </div>
        ))}
        {!messages?.length && (
          <p className="text-xs text-muted-foreground text-center py-6">No messages yet</p>
        )}
      </div>
    </motion.div>
  );
}

export default function Home() {
  const { user } = useAuth();
  const { data: agents } = trpc.agent.list.useQuery();
  const { data: swarms } = trpc.swarm.list.useQuery();
  const { data: capabilities } = trpc.capability.list.useQuery();

  const seedCapabilities = trpc.capability.seed.useMutation();

  useEffect(() => {
    if (capabilities && capabilities.length === 0) {
      seedCapabilities.mutate();
    }
  }, [capabilities]);

  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h1 className="text-3xl font-bold text-foreground neon-text">
            Welcome back, {user?.name?.split(" ")[0] ?? "Creator"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Your agent ecosystem is ready for orchestration
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6"
        >
          <StatCard
            icon={Bot}
            label="Active Agents"
            value={agents?.length ?? 0}
            color="bg-primary/20"
          />
          <StatCard
            icon={Hexagon}
            label="Swarms"
            value={swarms?.length ?? 0}
            color="bg-accent/20"
          />
          <StatCard
            icon={Sparkles}
            label="Capabilities"
            value={capabilities?.length ?? 0}
            color="bg-emerald-500/20"
          />
          <StatCard
            icon={Share2}
            label="Shared Agents"
            value={0}
            color="bg-amber-500/20"
          />
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6"
        >
          <div className="lg:col-span-2">
            <OpenClawEmbed />
          </div>
          <div className="space-y-4">
            <QuickActions />
            <RecentAgents />
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6"
        >
          <SwarmVisualizer />
          <ActivityFeed />
          <MessageStream />
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="mb-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Capability Hub</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {capabilities?.map((cap) => (
              <CapabilityTile
                key={cap.id}
                icon={
                  cap.icon === "brain"
                    ? Brain
                    : cap.icon === "mic"
                    ? Mic
                    : cap.icon === "video"
                    ? Video
                    : cap.icon === "zap"
                    ? Zap
                    : cap.icon === "scan"
                    ? Scan
                    : cap.icon === "ratio"
                    ? Image
                    : cap.icon === "sparkles"
                    ? Sparkles
                    : cap.icon === "headphones"
                    ? Volume2
                    : cap.icon === "spark"
                    ? Zap
                    : cap.icon === "image"
                    ? Image
                    : cap.icon === "map-pin"
                    ? MapPin
                    : cap.icon === "search"
                    ? Search
                    : cap.icon === "film"
                    ? Video
                    : cap.icon === "audio-lines"
                    ? Volume2
                    : cap.icon === "paintbrush"
                    ? Sparkles
                    : cap.icon === "volume-2"
                    ? Volume2
                    : cap.icon === "music"
                    ? Music
                    : Sparkles
                }
                label={cap.displayName}
                status={cap.isActive ? "ready" : "offline"}
                color={
                  cap.category === "intelligence"
                    ? "bg-primary/20"
                    : cap.category === "media"
                    ? "bg-accent/20"
                    : cap.category === "communication"
                    ? "bg-emerald-500/20"
                    : cap.category === "creative"
                    ? "bg-amber-500/20"
                    : "bg-white/10"
                }
              />
            ))}
          </div>
        </motion.div>
      </div>
    </AuthLayout>
  );
}
