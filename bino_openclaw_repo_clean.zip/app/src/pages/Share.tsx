import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Share2,
  Bot,
  Copy,
  Globe,
  Eye,
  Wrench,
  Pencil,
  Link,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

function ShareDialog({
  agent,
  open,
  onClose,
}: {
  agent: { id: number; name: string };
  open: boolean;
  onClose: () => void;
}) {
  const utils = trpc.useUtils();
  const createShare = trpc.share.create.useMutation({
    onSuccess: () => {
      utils.share.myShares.invalidate();
      onClose();
    },
  });

  const [isPublic, setIsPublic] = useState(false);
  const [permissionLevel, setPermissionLevel] = useState<"view" | "use" | "edit">("view");
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/share/${agent.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass border-white/10 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Share2 className="h-5 w-5 text-primary" />
            Share Agent
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
              <Bot className="h-4 w-4 text-primary" />
            </div>
            <span className="text-sm font-medium text-foreground">{agent.name}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              <Label className="text-foreground text-sm">Public Share</Label>
            </div>
            <Switch checked={isPublic} onCheckedChange={setIsPublic} />
          </div>

          <div>
            <Label className="text-foreground text-sm mb-2 block">Permission Level</Label>
            <div className="grid grid-cols-3 gap-2">
              {(["view", "use", "edit"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setPermissionLevel(level)}
                  className={`p-2 rounded-lg text-xs font-medium capitalize transition-all ${
                    permissionLevel === level
                      ? "bg-primary/20 text-primary border border-primary/30"
                      : "bg-white/5 text-muted-foreground border border-transparent hover:bg-white/10"
                  }`}
                >
                  {level === "view" && <Eye className="h-3 w-3 mx-auto mb-1" />}
                  {level === "use" && <Wrench className="h-3 w-3 mx-auto mb-1" />}
                  {level === "edit" && <Pencil className="h-3 w-3 mx-auto mb-1" />}
                  {level}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white/5">
            <Label className="text-foreground text-sm mb-2 block">Share Link</Label>
            <div className="flex items-center gap-2">
              <input
                value={shareUrl}
                readOnly
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-foreground font-mono"
              />
              <button
                onClick={handleCopy}
                className="p-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors"
              >
                <Copy className="h-4 w-4" />
              </button>
            </div>
            {copied && (
              <p className="text-[10px] text-emerald-400 mt-1">Copied to clipboard!</p>
            )}
          </div>

          <Button
            onClick={() =>
              createShare.mutate({
                agentId: agent.id,
                permissionLevel,
                isPublicShare: isPublic,
                shareToken: crypto.randomUUID(),
              })
            }
            className="w-full bg-primary hover:bg-primary/90"
            disabled={createShare.isPending}
          >
            {createShare.isPending ? "Sharing..." : "Generate Share Link"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Share() {
  const { data: agents } = trpc.agent.list.useQuery();
  const { data: myShares } = trpc.share.myShares.useQuery();
  const [selectedAgent, setSelectedAgent] = useState<{ id: number; name: string } | null>(null);

  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground neon-text">Agent Ecosystem</h1>
          <p className="text-sm text-muted-foreground">Share agents and collaborate with others</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <Bot className="h-4 w-4 text-primary" />
              Your Agents
            </h2>
            <div className="space-y-2">
              {agents?.map((agent) => (
                <motion.div
                  key={agent.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="glass rounded-lg p-3 flex items-center gap-3 hover:bg-white/10 transition-all cursor-pointer"
                  onClick={() => setSelectedAgent(agent)}
                >
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{agent.name}</p>
                    <p className="text-[10px] text-muted-foreground">{agent.model}</p>
                  </div>
                  <button className="p-1.5 rounded-lg hover:bg-white/10 transition-colors">
                    <Share2 className="h-4 w-4 text-primary" />
                  </button>
                </motion.div>
              ))}
              {!agents?.length && (
                <p className="text-sm text-muted-foreground text-center py-8">No agents to share</p>
              )}
            </div>
          </div>

          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <Link className="h-4 w-4 text-accent" />
              Active Shares
            </h2>
            <div className="space-y-2">
              {myShares?.map((share) => (
                <motion.div
                  key={share.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="glass rounded-lg p-3 flex items-center gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                    <Link className="h-4 w-4 text-accent" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{share.agent?.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] bg-white/10 text-muted-foreground px-1.5 py-0.5 rounded">
                        {share.permissionLevel}
                      </span>
                      {share.isPublicShare && (
                        <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded flex items-center gap-1">
                          <Globe className="h-2.5 w-2.5" /> Public
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      if (share.shareToken) {
                        navigator.clipboard.writeText(
                          `${window.location.origin}/share/${share.shareToken}`
                        );
                      }
                    }}
                    className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                  >
                    <Copy className="h-4 w-4 text-muted-foreground" />
                  </button>
                </motion.div>
              ))}
              {!myShares?.length && (
                <p className="text-sm text-muted-foreground text-center py-8">No active shares</p>
              )}
            </div>
          </div>
        </div>

        <div className="mt-8 glass rounded-xl p-6">
          <h2 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            Ecosystem Stats
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 rounded-lg bg-white/5">
              <p className="text-2xl font-bold text-foreground">{agents?.length ?? 0}</p>
              <p className="text-xs text-muted-foreground">Your Agents</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/5">
              <p className="text-2xl font-bold text-foreground">{myShares?.length ?? 0}</p>
              <p className="text-xs text-muted-foreground">Active Shares</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/5">
              <p className="text-2xl font-bold text-foreground">
                {myShares?.filter((s) => s.isPublicShare).length ?? 0}
              </p>
              <p className="text-xs text-muted-foreground">Public Shares</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/5">
              <p className="text-2xl font-bold text-foreground">
                {myShares?.filter((s) => s.permissionLevel === "edit").length ?? 0}
              </p>
              <p className="text-xs text-muted-foreground">Edit Permissions</p>
            </div>
          </div>
        </div>
      </div>

      {selectedAgent && (
        <ShareDialog
          agent={selectedAgent}
          open={true}
          onClose={() => setSelectedAgent(null)}
        />
      )}
    </AuthLayout>
  );
}
