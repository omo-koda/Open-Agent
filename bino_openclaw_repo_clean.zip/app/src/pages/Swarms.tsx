import AuthLayout from "@/components/AuthLayout";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Hexagon,
  Plus,
  Users,
  Crown,
  Eye,
  Wrench,
  Trash2,
  Settings,
  X,
} from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function CreateSwarmDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const utils = trpc.useUtils();
  const createSwarm = trpc.swarm.create.useMutation({
    onSuccess: () => {
      utils.swarm.list.invalidate();
      onClose();
    },
  });

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [orchestrationMode, setOrchestrationMode] = useState("round_robin");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createSwarm.mutate({
      name,
      description,
      orchestrationMode: orchestrationMode as "round_robin" | "hierarchical" | "democratic" | "competitive",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass border-white/10 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Plus className="h-5 w-5 text-accent" />
            Create Swarm
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div>
            <Label className="text-foreground">Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Swarm name..."
              className="bg-white/5 border-white/10 text-foreground mt-1"
              required
            />
          </div>
          <div>
            <Label className="text-foreground">Description</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this swarm do?"
              className="bg-white/5 border-white/10 text-foreground mt-1"
            />
          </div>
          <div>
            <Label className="text-foreground">Orchestration Mode</Label>
            <Select value={orchestrationMode} onValueChange={setOrchestrationMode}>
              <SelectTrigger className="bg-white/5 border-white/10 text-foreground mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass border-white/10">
                <SelectItem value="round_robin">Round Robin</SelectItem>
                <SelectItem value="hierarchical">Hierarchical</SelectItem>
                <SelectItem value="democratic">Democratic</SelectItem>
                <SelectItem value="competitive">Competitive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button
            type="submit"
            className="w-full bg-accent hover:bg-accent/90"
            disabled={createSwarm.isPending}
          >
            {createSwarm.isPending ? "Creating..." : "Create Swarm"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function SwarmCard({
  swarm,
  onDelete,
}: {
  swarm: {
    id: number;
    name: string;
    description: string | null;
    status: string;
    orchestrationMode: string;
    swarmAgents: Array<{ agent: { id: number; name: string; status: string } }>;
  };
  onDelete: (id: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const utils = trpc.useUtils();
  const { data: myAgents } = trpc.agent.list.useQuery();
  const addAgent = trpc.swarm.addAgent.useMutation({
    onSuccess: () => {
      utils.swarm.list.invalidate();
      utils.swarm.byId.invalidate({ id: swarm.id });
    },
  });
  const removeAgent = trpc.swarm.removeAgent.useMutation({
    onSuccess: () => {
      utils.swarm.list.invalidate();
    },
  });

  const statusColors: Record<string, string> = {
    idle: "bg-white/10 text-muted-foreground",
    active: "bg-emerald-500/20 text-emerald-400",
    paused: "bg-amber-500/20 text-amber-400",
    error: "bg-red-500/20 text-red-400",
  };

  const roleIcons: Record<string, React.ElementType> = {
    leader: Crown,
    worker: Users,
    observer: Eye,
    specialist: Wrench,
  };

  const availableAgents = myAgents?.filter(
    (a) => !swarm.swarmAgents.some((sa) => sa.agent.id === a.id)
  );

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      whileHover={{ y: -4 }}
      className="glass rounded-xl overflow-hidden hover:neon-glow transition-all"
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
              <Hexagon className="h-5 w-5 text-accent" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{swarm.name}</h3>
              <p className="text-[10px] text-muted-foreground capitalize">
                {swarm.orchestrationMode.replace("_", " ")}
              </p>
            </div>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors[swarm.status] ?? statusColors.idle}`}>
            {swarm.status}
          </span>
        </div>

        {swarm.description && (
          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{swarm.description}</p>
        )}

        <div className="mt-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
              Agents ({swarm.swarmAgents.length})
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {swarm.swarmAgents.map((sa) => {
              const RoleIcon = roleIcons[sa.agent.status] ?? Users;
              return (
                <span
                  key={sa.agent.id}
                  className="inline-flex items-center gap-1 text-[10px] bg-white/5 text-muted-foreground px-2 py-1 rounded-full"
                >
                  <RoleIcon className="h-2.5 w-2.5" />
                  {sa.agent.name}
                </span>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-1 mt-3 pt-3 border-t border-white/5">
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-white/5 transition-colors text-xs text-muted-foreground"
          >
            <Settings className="h-3 w-3" />
            Manage
          </button>
          <button
            onClick={() => onDelete(swarm.id)}
            className="p-1.5 rounded-lg hover:bg-red-500/10 transition-colors text-red-400"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden border-t border-white/5"
          >
            <div className="p-4 space-y-3">
              <div>
                <p className="text-xs font-medium text-foreground mb-2">Add Agent</p>
                <div className="space-y-1.5 max-h-32 overflow-y-auto">
                  {availableAgents?.map((agent) => (
                    <button
                      key={agent.id}
                      onClick={() =>
                        addAgent.mutate({
                          swarmId: swarm.id,
                          agentId: agent.id,
                          role: "worker",
                        })
                      }
                      className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 transition-colors text-left"
                    >
                      <Users className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="text-xs text-foreground">{agent.name}</span>
                      <Plus className="h-3 w-3 ml-auto text-primary" />
                    </button>
                  ))}
                  {!availableAgents?.length && (
                    <p className="text-xs text-muted-foreground text-center py-2">
                      All agents are in this swarm
                    </p>
                  )}
                </div>
              </div>

              {swarm.swarmAgents.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-foreground mb-2">Remove Agent</p>
                  <div className="space-y-1.5">
                    {swarm.swarmAgents.map((sa) => (
                      <button
                        key={sa.agent.id}
                        onClick={() =>
                          removeAgent.mutate({
                            swarmId: swarm.id,
                            agentId: sa.agent.id,
                          })
                        }
                        className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-red-500/10 transition-colors text-left"
                      >
                        <Users className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-xs text-foreground">{sa.agent.name}</span>
                        <X className="h-3 w-3 ml-auto text-red-400" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function Swarms() {
  const [createOpen, setCreateOpen] = useState(false);
  const utils = trpc.useUtils();
  const { data: swarms, isLoading } = trpc.swarm.list.useQuery();
  const deleteSwarm = trpc.swarm.delete.useMutation({
    onSuccess: () => utils.swarm.list.invalidate(),
  });

  return (
    <AuthLayout>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground neon-text">Swarm Orchestration</h1>
            <p className="text-sm text-muted-foreground">Coordinate multi-agent workflows</p>
          </div>
          <Button
            onClick={() => setCreateOpen(true)}
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Swarm
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="glass rounded-xl p-4 h-48 animate-pulse" />
            ))}
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence>
              {swarms?.map((swarm) => (
                <SwarmCard
                  key={swarm.id}
                  swarm={swarm}
                  onDelete={(id) => deleteSwarm.mutate({ id })}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}

        {!swarms?.length && !isLoading && (
          <div className="text-center py-16">
            <Hexagon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No swarms yet. Create your first swarm!</p>
          </div>
        )}

        <CreateSwarmDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      </div>
    </AuthLayout>
  );
}
